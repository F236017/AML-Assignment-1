﻿# Task 6 – Analysis

## 6.1 Why does logistic regression (Set R) score the same as the linear SVM?

Both models learn a **linear decision boundary** in the same 6-dimensional feature space
(Set R).  Logistic regression minimises binary cross-entropy and the linear SVM maximises
the margin, but both produce a hyperplane of the form theta^T x = 0.  Because the
hypothesis class is identical, they are constrained by the same limit: the classes must be
approximately linearly separable in (Ia, Ib, Ic, Va, Vb, Vc) for either model to succeed.
The similar accuracy (~70-75%) tells us the data is NOT linearly separable in raw features –
a single straight-line boundary cannot cleanly divide fault from no-fault samples.

## 6.2 Signs of Set Q weights

During a fault:
- **Currents (Ia, Ib, Ic) spike** – one or two phases carry very large current.
- **Voltages (Va, Vb, Vc) sag** – the short circuit pulls the faulted phase voltage toward zero.

Therefore:
- Weights on **I^2 terms are positive**: a larger squared current increases the probability
  of a fault, so the classifier pushes the output toward y=1.
- Weights on **V^2 terms are negative**: a larger squared voltage (healthy voltage) decreases
  the probability of a fault, pushing the output toward y=0.

This is consistent with what we observe: adding squared features gives the model a way to
separate fault/no-fault through the magnitude of the signals, not just their sign.

## 6.3 Support vectors: linear vs RBF SVM

A **large number of support vectors** means many training points lie inside the margin or
are misclassified – the boundary does not separate the classes well.  The linear SVM on
Set R has many support vectors because the data is not linearly separable in 6D.
The RBF kernel implicitly maps data into a much higher-dimensional space where the
classes become (approximately) linearly separable, so the RBF SVM finds a tighter margin
with far fewer support vectors.

## 6.4 Effect of C on validation accuracy and number of support vectors

C is the **regularisation trade-off**: larger C penalises margin violations more strongly,
pushing the hyperplane to fit the training data more tightly.

- For the **linear SVM** on non-separable data, increasing C allows fewer misclassifications
  on the training set but can overfit; accuracy may plateau or drop on the validation set.
- The number of support vectors generally **decreases** as C increases (smaller margin,
  fewer vectors needed to define it) – until the boundary starts memorising outliers.

## 6.5 Is the test accuracy optimistic or pessimistic for a real relay?

**Optimistic**.  Because the dataset contains consecutive time samples, adjacent rows look
almost identical.  A random split places highly correlated samples in both the training and
test sets.  The model essentially memorises temporal patterns from the same fault events.
A real relay must generalise to *new, unseen* fault events recorded in different operating
conditions.  A time-based split (train on early faults, test on later ones) would give a
more realistic estimate of deployment performance.

## 6.6 Which model would you deploy?

**Logistic regression on Set Q** is the best compromise: it achieves >95% accuracy and
drastically reduces **missed faults** (false negatives) compared to Set R.  A missed fault
(the relay fails to trip) can destroy expensive equipment or cause fires.  False alarms
(the relay trips unnecessarily) are expensive but recoverable.

If the highest possible accuracy is required and computational cost is acceptable, the
**RBF SVM** (~98% accuracy, fewest missed faults) would be the deployment choice.
However, for a real protection relay that must make a decision in milliseconds on embedded
hardware, logistic regression on Set Q is interpretable, fast, and already well above the
safety threshold.
