﻿# Can a Straight Line Detect a Power Fault? We Built a Classifier to Find Out

**By M. Hammad Azam (23F-6017) & Faizan Islam (23F-6026)**
*AI4003 Applied Machine Learning — FAST National University | Fall 2026*

---

## The Problem: A Relay That Must Never Miss

Imagine a 132 kV transmission line carrying power to an entire city. A tree branch falls on one phase. In a fraction of a second, the current on that phase spikes to five times normal, while the voltage collapses. A protective relay must detect this — and open the circuit breaker — within milliseconds. A missed detection means fire, destroyed transformers, and a city in darkness.

In this assignment we asked a machine learning question buried inside that engineering problem: **can a simple linear classifier (logistic regression) detect a fault from raw instantaneous measurements of Ia, Ib, Ic, Va, Vb, Vc?** And if not, what is the cheapest fix?

---

## The Dataset

We used the *Electrical Fault Detection and Classification* dataset from Kaggle — a MATLAB/Simulink simulation of a three-phase power system with approximately 12,000 samples. Each row is one instant in time with six measurements:

| Column | Meaning |
|--------|---------|
| Ia, Ib, Ic | Instantaneous line currents (A) |
| Va, Vb, Vc | Instantaneous line voltages (per unit) |
| Output (S) | Label: 1 = fault, 0 = no fault |

The dataset also contained two completely empty columns that carry zero information. After dropping them and renaming the label column to `fault`, we split the data using a fixed random seed:

- **Train:** 60% of rows
- **Validation:** 20% of rows
- **Test:** 20% of rows (touched only once at the very end)

---

## Figure 1 — What Does a Fault Look Like?

The first plot (Figure 1 below) shows the three line currents against row number for the first 2,000 samples, with the fault intervals shaded red.

> *Figure 1: Ia, Ib, Ic vs row number. Red shading marks fault periods.*

During faults, one or two current traces shoot far out of their normal range while the others may collapse. The signal is visually dramatic. But notice: the normal operating range of a healthy current already sweeps a wide band (the three phases are 120° apart and always sum to zero under balanced conditions). This wide spread overlaps with the fault region.

---

## Figure 2 — The Scatter Plot That Explains Everything

Plot Ia against Ib and colour every point by its fault label (Figure 2). The result is striking: fault points (red) and no-fault points (blue) form an *annular* pattern — fault samples appear at large radii while no-fault samples cluster near the origin, but there is no straight line that cleanly separates them.

> *Figure 2: Scatter plot of Ia vs Ib coloured by fault label.*

This is the core challenge. A linear classifier sees the world through the equation θ₀ + θ₁·Ia + θ₂·Ib = 0 and can only draw a straight boundary. The data is **not linearly separable** in (Ia, Ib).

---

## Logistic Regression — Built from Scratch

We implemented every component ourselves using only NumPy:

```python
def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))

def cost(X, y, theta):
    h = np.clip(sigmoid(X @ theta), 1e-12, 1 - 1e-12)
    m = len(y)
    return -(1/m) * np.sum(y * np.log(h) + (1-y) * np.log(1-h))

def fit_logistic(X, y, alpha, n_iters):
    theta = np.zeros(X.shape[1])
    costs = []
    for _ in range(n_iters):
        h = sigmoid(X @ theta)
        theta += (alpha / len(y)) * (X.T @ (y - h))
        costs.append(cost(X, y, theta))
    return theta, costs
```

The cost starts at log(2) ≈ 0.693 when θ = 0 (exactly as the theory predicts) and decreases at every iteration for our chosen learning rate.

### Set R: Raw Features Only

Training logistic regression on the six standardised raw features gave **~72% accuracy** on the test set, with *hundreds of missed faults*. The scatter plot already warned us: the boundary is the wrong shape.

### Set Q: Add the Squared Features

The fix is simple: append Ia², Ib², Ic², Va², Vb², Vc² to the feature vector. Now the classifier can separate classes based on *how far from zero* the signals are, not just their sign. The result: **~96% accuracy**, dramatically fewer missed faults.

**Why do the squared current weights have positive signs?**
During a fault, I² is large. A positive weight means large I² pushes the model toward predicting fault = 1. ✓

**Why do the squared voltage weights have negative signs?**
During a fault, voltage sags — V is small, so V² is small. A negative weight means *small* V² (less subtracted) increases the logit, also pushing toward fault = 1. ✓

The weights are physically interpretable, which is a wonderful sanity check.

---

## Figure 3 — J(θ) Against Iteration

We swept four learning rates (α ∈ {0.01, 0.1, 1, 10}) over 2,000 iterations.

> *Figure 3: Cost J(θ) vs iteration for Set Q. All four learning rates converge; α = 1 chosen.*

The largest α for which J decreases at *every single iteration* is our chosen learning rate. Too large and the cost oscillates (diverges). Too small and training is glacially slow.

---

## Support Vector Machines

We then trained SVMs using `sklearn.svm.SVC` — the only sklearn component allowed. No `StandardScaler`, no `train_test_split`, no `sklearn.metrics`. Everything else is ours.

### Linear SVM vs RBF SVM

| Kernel | C | γ | Val Accuracy | Support Vectors |
|--------|---|---|-------------|-----------------|
| Linear | 0.1 | – | ~71% | Many |
| Linear | 1 | – | ~73% | Many |
| Linear | 10 | – | ~73% | Many |
| Linear | 100 | – | ~73% | Many |
| RBF | 1 | 0.1 | ~95% | Fewer |
| RBF | 10 | 1 | ~98%+ | Fewest |

**Why does the linear SVM score the same as logistic regression on Set R?**
Both learn a linear decision boundary in the same 6-dimensional space. Same hypothesis class = same performance ceiling. It confirms the data is not linearly separable in raw features.

**What does a very large number of support vectors mean?**
When the boundary cannot cleanly separate the classes, many points end up inside the margin or misclassified. Each becomes a support vector. A large count signals a poor fit in that feature space.

**What happens to SVs as C increases?**
Higher C penalises margin violations more, forcing a tighter fit. Support vectors generally decrease (narrower margin), but on non-separable data, very high C may overfit without improving validation accuracy.

---

## Test Results: The Final Verdict

| Model | Accuracy | False Alarms | Missed Faults |
|-------|----------|-------------|---------------|
| Logistic Reg – Set R | ~72% | Low | **Hundreds** |
| Logistic Reg – Set Q | ~96% | Low | **Very few** |
| Linear SVM | ~73% | Low | **Hundreds** |
| RBF SVM (best) | ~98%+ | Very Low | **Minimal** |

### A Warning About Our Test Accuracy

The split was random across time samples. Adjacent rows (almost identical) land in both train and test. This means our model has seen the "shape" of every fault event — it has not been tested on genuinely *new* fault events. For a real relay, a time-based split would give a more honest estimate. Our numbers are likely **optimistic**.

---

## Which Model Would You Deploy?

For a real protection relay we would deploy **Logistic Regression on Set Q**:
- Fast inference (just 13 multiplications and a sigmoid)
- Interpretable weights with clear physical meaning
- ~96% accuracy, very few missed faults
- Deployable on microcontrollers with no sklearn dependency

If hardware budget allows and we need the absolute lowest missed-fault rate, the **RBF SVM** wins — but it requires storing all support vectors and running kernel evaluations, which is heavier.

> **The relay's prime directive: it is better to trip unnecessarily than to miss a real fault.**

---

## Conclusion

We showed that raw three-phase measurements are **not linearly separable**: both logistic regression and the linear SVM plateau around 72–73% with hundreds of missed faults. Adding squared features costs nothing computationally and pushes logistic regression to 96%. The RBF SVM goes further still, implicitly mapping to a high-dimensional space where the fault/no-fault annular boundary becomes linearly separable.

The full code, including our hand-coded gradient descent and our own `accuracy` and `confusion_matrix` functions, is on GitHub.

---

**GitHub Repository:** [YOUR REPO LINK HERE]
**LinkedIn Post:** [YOUR LINKEDIN LINK HERE]

*M. Hammad Azam (23F-6017) · Faizan Islam (23F-6026)*
*FAST National University of Computer and Emerging Sciences — Fall 2026*
