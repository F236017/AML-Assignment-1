﻿<!-- ============================================================
     GitHub Profile / Repository README
     AI4003 - Applied Machine Learning | Assignment 2
     Authors : M. Hammad Azam (23F-6017) | Faizan Islam (23F-6026)
     FAST-NUCES | Fall 2026
     ============================================================ -->

# ⚡ Detecting Faults on a Three-Phase Transmission Line

[![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python)](https://python.org)
[![NumPy](https://img.shields.io/badge/NumPy-Only-green?logo=numpy)](https://numpy.org)
[![Streamlit](https://img.shields.io/badge/Frontend-Streamlit-red?logo=streamlit)](https://streamlit.io)
[![License](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

> **AI4003 Applied Machine Learning — Assignment 2 | Fall 2026**
> FAST National University of Computer and Emerging Sciences

---

## 👥 Authors

| Name | Roll Number | GitHub |
|------|-------------|--------|
| **M. Hammad Azam** | 23F-6017 | [@HammadAzam](https://github.com/) |
| **Faizan Islam** | 23F-6026 | [@FaizanIslam](https://github.com/) |

---

## 🔌 Problem Statement

When a fault occurs on a transmission line, currents **spike** and voltages **sag**.
A protective relay must detect this within milliseconds and trip the breaker.

**Input:** Ia, Ib, Ic (A) and Va, Vb, Vc (pu) at one time instant
**Output:** y = 1 (fault) or y = 0 (no fault)

**The core question:** Can a straight-line decision boundary separate fault from no-fault
using raw measurements? If not — what is the cheapest fix?

---

## 📁 Repository Layout

```
data/
    detect_dataset.csv          ← download from Kaggle (see below)
src/
    load_data.py                ← exact appendix loader (not modified)
    prepare.py                  ← Task 1: clean, split, standardise
    eda.py                      ← Task 2: 3 exploratory plots
    logistic.py                 ← sigmoid, hypothesis, cost, fit_logistic, predict
    metrics.py                  ← accuracy, confusion_matrix (NumPy only)
    train_logistic.py           ← Task 3: alpha sweep, train, report θ
    train_svm.py                ← Task 4: linear + RBF grid, save best models
    test_models.py              ← Task 5: evaluate on test set (once only)
results/
    analysis.md                 ← Task 6: written analysis answers
    figures/
        project_poster.jpg      ← project poster
        fig_sigmoid.jpg         ← sigmoid function figure
        fig_cost_convergence.jpg← J(θ) convergence curves
        (+ generated plots from eda.py and train_logistic.py)
    linkedin_post.txt           ← LinkedIn post text
    medium_blog.md              ← Medium blog (800-1500 words)
    github_readme_profile.md    ← this file
app/
    app.py                      ← Streamlit web interface (Task 7)
README.md                       ← how to run everything
```

---

## 🔒 Allowed Libraries

```
numpy · pandas · matplotlib · joblib · streamlit
sklearn.svm.SVC   ← the ONLY sklearn module used
```

**Banned (not used anywhere):**
`LogisticRegression` · `train_test_split` · `StandardScaler` · `sklearn.metrics.*`

---

## 📊 Results Summary

### Table 2 — Logistic Regression

| Feature Set | Chosen α | Final J(θ) | Validation Accuracy |
|-------------|----------|-----------|---------------------|
| Set R (6 raw) | 1.0 | ~0.55 | ~72% |
| Set Q (6+6 squared) | 1.0 | ~0.08 | ~96% |

### Table 4 — Test Results

| Model | Accuracy | False Alarms | Missed Faults |
|-------|----------|-------------|---------------|
| Logistic Reg – Set R | ~72% | Low | **Hundreds** |
| Logistic Reg – Set Q | ~96% | Low | **Very few** |
| Linear SVM (best C) | ~73% | Low | **Hundreds** |
| RBF SVM (best C, γ) | **~98%+** | Very Low | **Minimal** |

---

## 🚀 Quick Start

### 1. Get the data
```
https://www.kaggle.com/datasets/esathyaprakash/electrical-fault-detection-and-classification
```
Download, unzip, place `detect_dataset.csv` → `data/`

### 2. Install dependencies
```bash
pip install numpy pandas matplotlib scikit-learn joblib streamlit
```

### 3. Run in order
```bash
python src/load_data.py         # verify the CSV loads
python src/prepare.py           # clean, split, standardise, save stats
python src/eda.py               # generate 3 plots in results/
python src/train_logistic.py    # choose alpha, train, print theta table
python src/train_svm.py         # train all SVMs, save best models
python src/test_models.py       # evaluate on test set (ONCE)
```

### 4. Launch web app
```bash
streamlit run app/app.py
```
Enter Ia, Ib, Ic, Va, Vb, Vc → see fault prediction from logistic regression (Set Q)
and RBF SVM side by side.

---

## 🔍 Key Findings

1. **Linear classifiers fail on raw features.** Both logistic regression (Set R) and the linear
   SVM score ~72–73% — they share the same hypothesis class (a hyperplane), and the data is
   not linearly separable in raw (Ia, Ib, Ic, Va, Vb, Vc).

2. **Squared features are the cheapest fix.** Adding Ia², Ib², Ic², Va², Vb², Vc² to the
   feature vector costs zero additional sensors but boosts accuracy to ~96%, because fault
   detection depends on *signal magnitude*, not sign.

3. **The RBF kernel implicitly does the same thing better.** By mapping to infinite dimensions,
   it achieves ~98%+ with the fewest missed faults.

4. **Missed faults matter more than false alarms.** A relay that misses a fault can destroy
   equipment. A relay that trips unnecessarily is just inconvenient.

---

## 📝 Links

- 📖 **Medium Blog:** [Read the full article →](https://medium.com/)
- 💼 **LinkedIn Post:** [See the post →](https://linkedin.com/)

---

*© 2026 M. Hammad Azam & Faizan Islam — FAST-NUCES | AI4003 Applied Machine Learning*
