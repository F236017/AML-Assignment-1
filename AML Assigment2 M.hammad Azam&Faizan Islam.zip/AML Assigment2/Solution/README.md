﻿# AI4003 – Assignment 2: Detecting Faults on a Three-Phase Transmission Line

Logistic regression (from scratch) + SVM (sklearn.svm.SVC) fault classifier.

## Repository Layout

```
data/
    detect_dataset.csv        ← download from Kaggle (see below)
src/
    load_data.py              ← exact loader from assignment appendix
    prepare.py                ← Task 1: clean, split, standardise
    eda.py                    ← Task 2: exploratory plots
    logistic.py               ← sigmoid, hypothesis, cost, fit_logistic, predict
    metrics.py                ← accuracy, confusion_matrix (numpy only)
    train_logistic.py         ← Task 3: choose alpha, train, report
    train_svm.py              ← Task 4: linear + RBF SVM grid, save best models
    test_models.py            ← Task 5: evaluate on test set (ONCE)
results/
    analysis.md               ← Task 6: written answers
    *.png                     ← generated figures
    *.npy                     ← saved theta vectors and training stats
    *.pkl                     ← saved SVM models (joblib)
app/
    app.py                    ← Task 7: Streamlit front end
README.md
```

## Allowed Libraries

`numpy`, `pandas`, `matplotlib`, `joblib`, `streamlit` (front-end),  
and from scikit-learn **only** `sklearn.svm.SVC`.

**Not used anywhere:** `LogisticRegression`, `train_test_split`, `StandardScaler`,  
anything from `sklearn.metrics`, or any library that automates data splitting,  
feature scaling, model fitting or metric computation.

## Getting Started

### 1. Download the data

```
https://www.kaggle.com/datasets/esathyaprakash/electrical-fault-detection-and-classification
```

Download, unzip, and place **`detect_dataset.csv`** in the `data/` folder.

### 2. Install dependencies

```bash
pip install numpy pandas matplotlib scikit-learn joblib streamlit
```

### 3. Run in order

```bash
# From the Solution/ directory
python src/load_data.py         # verify the CSV loads (prints shape + head)
python src/prepare.py           # clean, split, standardise, save stats
python src/eda.py               # generate 3 exploratory plots in results/
python src/train_logistic.py    # choose alpha, train, print theta
python src/train_svm.py         # train all SVMs, save best models
python src/test_models.py       # evaluate on test set (run only ONCE)
```

### 4. Launch the web app

```bash
streamlit run app/app.py
```

Enter values for Ia, Ib, Ic, Va, Vb, Vc and click **Predict** to see fault predictions  
from the logistic regression (Set Q) and the best RBF SVM side by side.

## Correctness Checks (per assignment specification)

- [ ] Empty columns and the label column are **not** in the feature matrices.
- [ ] Standardisation statistics come from **training rows only**.
- [ ] J(theta) starts at log(2) ≈ 0.693 when theta = 0.
- [ ] J(theta) decreases at every iteration with the chosen alpha.
- [ ] Confusion matrix entries sum to the number of test rows.
- [ ] Test rows are **never** used for training or for choosing alpha, C, or gamma.
