﻿"""Task 5.1 – Metrics implemented from scratch with NumPy only.

No sklearn.metrics allowed.
"""

import numpy as np


def accuracy(y_true, y_pred):
    """Fraction of correctly classified samples.

    Accuracy = (1/m) * sum_i 1[y_pred^(i) == y_true^(i)]
    """
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    return float(np.mean(y_true == y_pred))


def confusion_matrix(y_true, y_pred):
    """2x2 confusion matrix.

    Returns a numpy array:
        [[TN, FP],
         [FN, TP]]

    where:
        TN = actual 0, predicted 0  (correct no-fault)
        FP = actual 0, predicted 1  (false alarm)
        FN = actual 1, predicted 0  (missed fault -- dangerous!)
        TP = actual 1, predicted 1  (correct fault)
    """
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)

    tn = int(np.sum((y_true == 0) & (y_pred == 0)))
    fp = int(np.sum((y_true == 0) & (y_pred == 1)))
    fn = int(np.sum((y_true == 1) & (y_pred == 0)))
    tp = int(np.sum((y_true == 1) & (y_pred == 1)))

    return np.array([[tn, fp],
                     [fn, tp]])
