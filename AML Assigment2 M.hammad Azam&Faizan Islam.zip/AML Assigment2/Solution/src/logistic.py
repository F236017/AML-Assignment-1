﻿"""Task 3 – Logistic regression implemented from scratch with NumPy only.

Functions
---------
sigmoid(z)
hypothesis(X, theta)
cost(X, y, theta)         -- binary cross-entropy J(theta)
fit_logistic(X, y, alpha, n_iters)
predict(X, theta)
"""

import numpy as np


def sigmoid(z):
    """Logistic (sigmoid) function, element-wise."""
    return 1.0 / (1.0 + np.exp(-z))


def hypothesis(X, theta):
    """h_theta(x) = sigmoid(X @ theta)."""
    return sigmoid(X @ theta)


def cost(X, y, theta):
    """Binary cross-entropy cost J(theta).

    Clips h to [1e-12, 1-1e-12] before taking the log.
    """
    h = hypothesis(X, theta)
    h = np.clip(h, 1e-12, 1.0 - 1e-12)
    m = len(y)
    return -(1.0 / m) * np.sum(
        y * np.log(h) + (1.0 - y) * np.log(1.0 - h)
    )


def fit_logistic(X, y, alpha, n_iters):
    """Batch gradient ascent on the log-likelihood (= descent on J).

    Starts from theta = 0 and applies, for every j:
        theta_j := theta_j + alpha/n * sum_i ( y^(i) - h(x^(i)) ) x_j^(i)

    Returns
    -------
    theta  : final parameter vector  (shape [n+1])
    costs  : list of J(theta) recorded after each iteration
    """
    m, n = X.shape
    theta = np.zeros(n)
    costs = []

    for _ in range(n_iters):
        h = hypothesis(X, theta)
        gradient = (1.0 / m) * (X.T @ (y - h))   # shape [n]
        theta = theta + alpha * gradient
        costs.append(cost(X, y, theta))

    return theta, costs


def predict(X, theta):
    """Return 1 if h_theta(x) >= 0.5, else 0."""
    return (hypothesis(X, theta) >= 0.5).astype(int)
