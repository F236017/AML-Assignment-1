﻿"""Task 2 – Exploratory data analysis plots.

All three plots use RAW (unstandardised) data.
Saves plots to results/.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from src.load_data import load_raw


def plot_eda(data_dir="data", results_dir="results"):
    Path(results_dir).mkdir(parents=True, exist_ok=True)

    # Load and clean (same cleaning as prepare.py, but keep RAW values)
    df = load_raw(data_dir)
    cols_to_drop = [
        c for c in df.columns
        if df[c].isna().all() or df[c].nunique() <= 1
    ]
    df = df.drop(columns=cols_to_drop)
    df = df.rename(columns={"Output (S)": "fault"})
    df = df.reset_index(drop=True)   # ensure integer row index

    # ------------------------------------------------------------------
    # 2.1  Ia, Ib, Ic against row number for the first 2000 rows,
    #      background shaded wherever fault=1.
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(14, 5))
    sub = df.iloc[:2000].copy()

    ax.plot(sub.index, sub["Ia"], label="Ia", linewidth=0.8)
    ax.plot(sub.index, sub["Ib"], label="Ib", linewidth=0.8)
    ax.plot(sub.index, sub["Ic"], label="Ic", linewidth=0.8)

    # Shade fault regions
    in_fault = False
    start = None
    for i in sub.index:
        f = sub.loc[i, "fault"]
        if f == 1 and not in_fault:
            start = i
            in_fault = True
        elif f == 0 and in_fault:
            ax.axvspan(start, i, color="red", alpha=0.25, lw=0)
            in_fault = False
    if in_fault:
        ax.axvspan(start, sub.index[-1], color="red", alpha=0.25, lw=0)

    ax.set_title("Line currents vs row number – first 2 000 rows (red = fault)")
    ax.set_xlabel("Row number")
    ax.set_ylabel("Current (A)")
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(Path(results_dir) / "plot_2_1_currents.png", dpi=150)
    plt.close(fig)
    print("Saved plot_2_1_currents.png")

    # ------------------------------------------------------------------
    # 2.2  Scatter plot of Ia against Ib, coloured by fault label.
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7, 6))
    colours = df["fault"].map({0: "#2196F3", 1: "#F44336"})
    ax.scatter(df["Ia"], df["Ib"], c=colours, s=2, alpha=0.4, rasterized=True)
    ax.set_title("Scatter: Ia vs Ib  (blue = no-fault, red = fault)")
    ax.set_xlabel("Ia (A)")
    ax.set_ylabel("Ib (A)")
    # Legend proxies
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], marker="o", color="w", markerfacecolor="#2196F3",
               markersize=8, label="No fault"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor="#F44336",
               markersize=8, label="Fault"),
    ]
    ax.legend(handles=legend_elements)
    fig.tight_layout()
    fig.savefig(Path(results_dir) / "plot_2_2_scatter.png", dpi=150)
    plt.close(fig)
    print("Saved plot_2_2_scatter.png")

    # ------------------------------------------------------------------
    # 2.3  Histogram of Ia for fault rows and no-fault rows.
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(df.loc[df["fault"] == 0, "Ia"], bins=80, density=True,
            alpha=0.6, color="#2196F3", label="No fault")
    ax.hist(df.loc[df["fault"] == 1, "Ia"], bins=80, density=True,
            alpha=0.6, color="#F44336", label="Fault")
    ax.set_title("Histogram of Ia by fault label")
    ax.set_xlabel("Ia (A)")
    ax.set_ylabel("Density")
    ax.legend()
    fig.tight_layout()
    fig.savefig(Path(results_dir) / "plot_2_3_histogram.png", dpi=150)
    plt.close(fig)
    print("Saved plot_2_3_histogram.png")


if __name__ == "__main__":
    plot_eda()
