﻿"""Task 3 – Choose alpha, train, and evaluate logistic regression.

3.4  Run 2000 iterations for alpha in {0.01, 0.1, 1, 10} on TRAINING rows.
     Plot J(theta) vs iteration for all four values (one figure per feature set).
     Pick the LARGEST alpha for which J decreases at EVERY iteration.

3.5  Train the final model with the chosen alpha and 2000 iterations.
     Report training and validation accuracy. Print theta.

Uses ONLY: numpy, matplotlib, and our own src modules.
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")            # non-interactive backend -- safe on all machines
import matplotlib.pyplot as plt
import sys
import joblib
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from src.prepare   import prepare_data
from src.logistic  import fit_logistic, predict, cost
from src.metrics   import accuracy


ALPHAS  = [0.01, 0.1, 1.0, 10.0]
N_ITERS = 2000
FEATURES_Q = ["Ia", "Ib", "Ic", "Va", "Vb", "Vc",
               "Ia^2", "Ib^2", "Ic^2", "Va^2", "Vb^2", "Vc^2"]


def _is_monotone_decreasing(costs):
    """True iff J decreases at EVERY iteration (strict check)."""
    arr = np.array(costs)
    return bool(np.all(arr[1:] <= arr[:-1]))


def _add_bias(X):
    """Prepend a column of ones (theta_0 / intercept)."""
    return np.hstack([np.ones((X.shape[0], 1)), X])


def train_logistic(data_dir="data", results_dir="results"):
    Path(results_dir).mkdir(parents=True, exist_ok=True)

    (X_train_R, y_train,
     X_val_R,   y_val,
     X_test_R,  y_test,
     X_train_Q, X_val_Q, X_test_Q) = prepare_data(data_dir, results_dir)

    # Add bias term (intercept)
    Xtr_R = _add_bias(X_train_R)
    Xv_R  = _add_bias(X_val_R)
    Xtr_Q = _add_bias(X_train_Q)
    Xv_Q  = _add_bias(X_val_Q)

    results = {}

    # ------------------------------------------------------------------
    # Iterate over both feature sets
    # ------------------------------------------------------------------
    for label, Xtr, Xv in [("Set R", Xtr_R, Xv_R),
                             ("Set Q", Xtr_Q, Xv_Q)]:
        print(f"\n{'='*60}")
        print(f"  Feature set: {label}  (shape {Xtr.shape})")
        print(f"{'='*60}")

        # ---- 3.4  Explore learning rates ----
        fig, ax = plt.subplots(figsize=(10, 5))
        chosen_alpha = None

        for alpha in ALPHAS:
            _, costs = fit_logistic(Xtr, y_train, alpha, N_ITERS)
            ax.plot(costs, label=f"alpha={alpha}")
            if _is_monotone_decreasing(costs):
                # Keep the LARGEST valid alpha
                chosen_alpha = max(chosen_alpha or 0, alpha)

        ax.set_title(f"J(theta) vs iteration – {label}")
        ax.set_xlabel("Iteration")
        ax.set_ylabel("J(theta)")
        ax.legend()
        fig.tight_layout()
        fname = f"cost_{label.replace(' ', '_')}.png"
        fig.savefig(Path(results_dir) / fname, dpi=150)
        plt.close(fig)
        print(f"Saved {fname}")
        print(f"  Chosen alpha = {chosen_alpha}")

        # ---- 3.5  Train final model ----
        theta, costs = fit_logistic(Xtr, y_train, chosen_alpha, N_ITERS)
        final_J      = costs[-1]

        train_acc = accuracy(y_train, predict(Xtr, theta))
        val_acc   = accuracy(y_val,   predict(Xv,  theta))

        print(f"  Final J(theta)      = {final_J:.6f}")
        print(f"  Training accuracy   = {train_acc:.4f}")
        print(f"  Validation accuracy = {val_acc:.4f}")
        print(f"  theta               = {theta}")

        results[label] = dict(
            chosen_alpha=chosen_alpha,
            final_J=final_J,
            train_acc=train_acc,
            val_acc=val_acc,
            theta=theta,
        )

        # Save theta
        tag = label.replace(" ", "_")
        np.save(Path(results_dir) / f"theta_{tag}.npy", theta)
        print(f"  Saved theta_{tag}.npy")

    # ------------------------------------------------------------------
    # Table 2 – Logistic regression summary
    # ------------------------------------------------------------------
    print("\n--- Table 2: Logistic regression ---")
    print(f"{'Feature set':<10} {'Chosen alpha':>14} {'Final J(theta)':>16} {'Val accuracy':>14}")
    for lbl, r in results.items():
        print(f"{lbl:<10} {r['chosen_alpha']:>14.2f} {r['final_J']:>16.6f} {r['val_acc']:>14.4f}")

    # ------------------------------------------------------------------
    # Table 5 – theta for Set Q  (13 rows: intercept + 12 features)
    # ------------------------------------------------------------------
    feature_names_Q = ["intercept"] + FEATURES_Q
    theta_Q = results["Set Q"]["theta"]
    print("\n--- Table 5: Learned theta (Set Q) ---")
    print(f"{'Feature':<15}  {'theta':>12}")
    for fname, w in zip(feature_names_Q, theta_Q):
        print(f"  {fname:<13}  {w:>12.6f}")


if __name__ == "__main__":
    train_logistic()
