﻿"""Task 5 – Evaluate the four final models on the test set (ONCE).

5.2  Logistic regression Set R, logistic regression Set Q,
     best linear SVM, best RBF SVM.
5.3  Report accuracy, confusion matrix, missed faults for each.

Uses ONLY: numpy, joblib, and our own src modules.
"""

import numpy as np
import sys
import joblib
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from src.prepare  import prepare_data
from src.logistic import predict
from src.metrics  import accuracy, confusion_matrix


def _add_bias(X):
    return np.hstack([np.ones((X.shape[0], 1)), X])


def test_models(data_dir="data", results_dir="results"):
    results_dir = Path(results_dir)

    (X_train_R, y_train,
     X_val_R,   y_val,
     X_test_R,  y_test,
     X_train_Q, X_val_Q, X_test_Q) = prepare_data(data_dir, str(results_dir))

    # Add bias for logistic regression
    Xte_R_log = _add_bias(X_test_R)
    Xte_Q_log = _add_bias(X_test_Q)

    # Load parameters
    theta_R = np.load(results_dir / "theta_Set_R.npy")
    theta_Q = np.load(results_dir / "theta_Set_Q.npy")
    linear_svm = joblib.load(results_dir / "best_linear_svm.pkl")
    rbf_svm    = joblib.load(results_dir / "best_rbf_svm.pkl")

    models = [
        ("Logistic regression, Set R",
         lambda: predict(Xte_R_log, theta_R)),
        ("Logistic regression, Set Q",
         lambda: predict(Xte_Q_log, theta_Q)),
        (f"Linear SVM (C={linear_svm.C})",
         lambda: linear_svm.predict(X_test_R)),
        (f"RBF SVM (C={rbf_svm.C}, gamma={rbf_svm.gamma})",
         lambda: rbf_svm.predict(X_test_R)),
    ]

    # ------------------------------------------------------------------
    # Table 4 – Test results
    # ------------------------------------------------------------------
    header = f"{'Model':<38} | {'Acc':>7} | {'TN':>6} | {'FA':>6} | {'MF':>6} | {'TP':>6}"
    print("\n--- Table 4: Test results ---")
    print(header)
    print("-" * len(header))

    for name, pred_fn in models:
        preds = pred_fn()
        acc   = accuracy(y_test, preds)
        cm    = confusion_matrix(y_test, preds)
        tn, fp, fn, tp = cm[0, 0], cm[0, 1], cm[1, 0], cm[1, 1]
        print(f"{name:<38} | {acc:>7.4f} | {tn:>6} | {fp:>6} | {fn:>6} | {tp:>6}")
    print("  (FA = false alarms, MF = missed faults)\n")

    # Verify confusion matrix entries sum to test size
    preds_r = models[0][1]()
    cm_r = confusion_matrix(y_test, preds_r)
    assert cm_r.sum() == len(y_test), "Confusion matrix sum does not match test size!"
    print(f"Sanity check: CM entries sum = {cm_r.sum()} = {len(y_test)} test rows  OK")


if __name__ == "__main__":
    test_models()
