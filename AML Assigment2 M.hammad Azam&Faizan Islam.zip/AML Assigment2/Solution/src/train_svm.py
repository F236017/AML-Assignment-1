﻿"""Task 4 – Support vector machines on Set R only.

4.1  Linear SVM: SVC(kernel="linear", C=C) for C in {0.1, 1, 10, 100}.
4.2  RBF SVM:    SVC(kernel="rbf", C=C, gamma=gamma)
                 for C in {0.1, 1, 10, 100} and gamma in {0.1, 1} (8 models).
4.3  Results table: C, gamma, validation accuracy, number of support vectors.
4.4  Save best linear and best RBF model with joblib.dump.

FIGURE:  Validation accuracy vs C for linear SVM and RBF SVM (both gamma),
         C on a log scale.

Allowed sklearn: sklearn.svm.SVC only.
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import sys
import joblib
from pathlib import Path
from sklearn.svm import SVC

sys.path.append(str(Path(__file__).parent.parent))
from src.prepare  import prepare_data
from src.metrics  import accuracy   # our own implementation


LINEAR_CS  = [0.1, 1, 10, 100]
RBF_CS     = [0.1, 1, 10, 100]
RBF_GAMMAS = [0.1, 1]


def _add_bias(X):
    """Prepend a column of ones (not needed by SVC, but kept for consistency)."""
    return X   # SVC handles the intercept internally


def train_svm(data_dir="data", results_dir="results"):
    Path(results_dir).mkdir(parents=True, exist_ok=True)

    (X_train_R, y_train,
     X_val_R,   y_val,
     _,         _,
     _,         _,     _) = prepare_data(data_dir, results_dir)

    rows_linear = []
    rows_rbf    = []

    best_linear_acc   = -1
    best_linear_model = None
    best_linear_C     = None

    best_rbf_acc   = -1
    best_rbf_model = None
    best_rbf_C     = None
    best_rbf_gamma = None

    # ------------------------------------------------------------------
    # 4.1  Linear SVM
    # ------------------------------------------------------------------
    print("\n--- Linear SVM ---")
    print(f"{'C':>6} | {'Val acc':>9} | {'Num SVs':>9}")
    print("-" * 30)

    for C in LINEAR_CS:
        model = SVC(kernel="linear", C=C)
        model.fit(X_train_R, y_train)
        preds   = model.predict(X_val_R)
        val_acc = accuracy(y_val, preds)
        n_sv    = int(model.n_support_.sum())

        print(f"{C:>6} | {val_acc:>9.4f} | {n_sv:>9}")
        rows_linear.append(dict(C=C, gamma="–", val_acc=val_acc, n_sv=n_sv))

        if val_acc > best_linear_acc:
            best_linear_acc   = val_acc
            best_linear_model = model
            best_linear_C     = C

    # ------------------------------------------------------------------
    # 4.2  RBF SVM
    # ------------------------------------------------------------------
    print("\n--- RBF SVM ---")
    print(f"{'C':>6} | {'gamma':>6} | {'Val acc':>9} | {'Num SVs':>9}")
    print("-" * 38)

    for C in RBF_CS:
        for gamma in RBF_GAMMAS:
            model = SVC(kernel="rbf", C=C, gamma=gamma)
            model.fit(X_train_R, y_train)
            preds   = model.predict(X_val_R)
            val_acc = accuracy(y_val, preds)
            n_sv    = int(model.n_support_.sum())

            print(f"{C:>6} | {gamma:>6} | {val_acc:>9.4f} | {n_sv:>9}")
            rows_rbf.append(dict(C=C, gamma=gamma, val_acc=val_acc, n_sv=n_sv))

            if val_acc > best_rbf_acc:
                best_rbf_acc   = val_acc
                best_rbf_model = model
                best_rbf_C     = C
                best_rbf_gamma = gamma

    print(f"\nBest linear SVM : C={best_linear_C}, val_acc={best_linear_acc:.4f}")
    print(f"Best RBF    SVM : C={best_rbf_C}, gamma={best_rbf_gamma}, val_acc={best_rbf_acc:.4f}")

    # ------------------------------------------------------------------
    # 4.3  Full table (for reporting)
    # ------------------------------------------------------------------
    print("\n--- Table 3: SVM validation results ---")
    print(f"{'Kernel':<8} | {'C':>6} | {'gamma':>6} | {'Val acc':>9} | {'Num SVs':>9}")
    print("-" * 52)
    for r in rows_linear:
        print(f"{'linear':<8} | {r['C']:>6} | {str(r['gamma']):>6} | {r['val_acc']:>9.4f} | {r['n_sv']:>9}")
    for r in rows_rbf:
        print(f"{'rbf':<8} | {r['C']:>6} | {r['gamma']:>6} | {r['val_acc']:>9.4f} | {r['n_sv']:>9}")

    # ------------------------------------------------------------------
    # 4.4  Save best models
    # ------------------------------------------------------------------
    joblib.dump(best_linear_model, Path(results_dir) / "best_linear_svm.pkl")
    joblib.dump(best_rbf_model,    Path(results_dir) / "best_rbf_svm.pkl")
    print("\nSaved best_linear_svm.pkl and best_rbf_svm.pkl")

    # ------------------------------------------------------------------
    # Figure: Validation accuracy vs C (log scale)
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 5))

    # Linear
    linear_accs = [r["val_acc"] for r in rows_linear]
    ax.plot(LINEAR_CS, linear_accs, "o-", label="Linear SVM", color="#1976D2")

    # RBF per gamma
    for gamma in RBF_GAMMAS:
        rbf_accs = [r["val_acc"] for r in rows_rbf if r["gamma"] == gamma]
        ax.plot(RBF_CS, rbf_accs, "s--",
                label=f"RBF (gamma={gamma})")

    ax.set_xscale("log")
    ax.set_xticks(LINEAR_CS)
    ax.get_xaxis().set_major_formatter(plt.ScalarFormatter())
    ax.set_xlabel("C")
    ax.set_ylabel("Validation accuracy")
    ax.set_title("Validation accuracy vs C  (Set R)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(Path(results_dir) / "plot_svm_val_acc.png", dpi=150)
    plt.close(fig)
    print("Saved plot_svm_val_acc.png")


if __name__ == "__main__":
    train_svm()
