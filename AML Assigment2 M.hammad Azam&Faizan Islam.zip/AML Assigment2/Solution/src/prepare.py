﻿"""Task 1 – Load and prepare the data.

Saves training statistics (mean and std) to results/ so that
the app and test scripts can standardise new inputs consistently.
"""

import numpy as np
import pandas as pd
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from src.load_data import load_raw


FEATURES = ["Ia", "Ib", "Ic", "Va", "Vb", "Vc"]


def prepare_data(data_dir="data", results_dir="results"):
    # ------------------------------------------------------------------
    # 1.1  Load
    # ------------------------------------------------------------------
    df = load_raw(data_dir)
    print(f"Raw shape: {df.shape[0]} rows, {df.shape[1]} columns")
    print("Column names:", df.columns.tolist())
    print(df.head(5).to_string(), "\n")

    # ------------------------------------------------------------------
    # 1.2  Inspect and clean
    #      Remove columns that carry no information:
    #        - all values missing, OR
    #        - only one unique value
    #      Rename the label column to 'fault'.
    # ------------------------------------------------------------------
    cols_to_drop = [
        c for c in df.columns
        if df[c].isna().all() or df[c].nunique() <= 1
    ]
    df = df.drop(columns=cols_to_drop)
    print(f"Removed columns (no information): {cols_to_drop}")

    df = df.rename(columns={"Output (S)": "fault"})

    # Confirm numeric types
    print("\nDtypes after cleaning:")
    print(df[FEATURES].dtypes)
    print("\nMissing values per column after cleaning:")
    print(df.isna().sum())

    # ------------------------------------------------------------------
    # 1.3  Class counts
    # ------------------------------------------------------------------
    n_fault     = int((df["fault"] == 1).sum())
    n_no_fault  = int((df["fault"] == 0).sum())
    print(f"\nFault rows   (y=1): {n_fault}")
    print(f"No-fault rows (y=0): {n_no_fault}")

    # ------------------------------------------------------------------
    # 1.4  Split – EXACTLY the code given in the assignment
    # ------------------------------------------------------------------
    rng = np.random.default_rng(42)
    idx = rng.permutation(len(df))
    n_train, n_val = int(0.6 * len(df)), int(0.2 * len(df))
    train_idx = idx[:n_train]
    val_idx   = idx[n_train:n_train + n_val]
    test_idx  = idx[n_train + n_val:]

    df_train = df.iloc[train_idx].copy()
    df_val   = df.iloc[val_idx].copy()
    df_test  = df.iloc[test_idx].copy()

    print()
    for name, split in zip(["Train", "Validation", "Test"],
                            [df_train, df_val, df_test]):
        frac = split["fault"].mean()
        print(f"  {name:11s}: {len(split):5d} rows, fault fraction = {frac:.4f}")

    # ------------------------------------------------------------------
    # 1.5  Standardise – statistics from TRAINING rows only
    # ------------------------------------------------------------------

    # ---- Set R : 6 raw features ----
    mean_R = df_train[FEATURES].mean()   # pandas Series
    std_R  = df_train[FEATURES].std()

    X_train_R = (df_train[FEATURES] - mean_R) / std_R
    X_val_R   = (df_val[FEATURES]   - mean_R) / std_R
    X_test_R  = (df_test[FEATURES]  - mean_R) / std_R

    # ---- Set Q : 6 raw + 6 squared features ----
    df_train_Q = df_train[FEATURES].copy()
    df_val_Q   = df_val[FEATURES].copy()
    df_test_Q  = df_test[FEATURES].copy()

    for col in FEATURES:
        sq = f"{col}^2"
        df_train_Q[sq] = df_train_Q[col] ** 2
        df_val_Q[sq]   = df_val_Q[col]   ** 2
        df_test_Q[sq]  = df_test_Q[col]  ** 2

    mean_Q = df_train_Q.mean()
    std_Q  = df_train_Q.std()

    X_train_Q = (df_train_Q - mean_Q) / std_Q
    X_val_Q   = (df_val_Q   - mean_Q) / std_Q
    X_test_Q  = (df_test_Q  - mean_Q) / std_Q

    # ---- Labels ----
    y_train = df_train["fault"].values
    y_val   = df_val["fault"].values
    y_test  = df_test["fault"].values

    # ------------------------------------------------------------------
    # Save training statistics so the app can standardise user inputs
    # ------------------------------------------------------------------
    Path(results_dir).mkdir(parents=True, exist_ok=True)
    np.save(Path(results_dir) / "mean_R.npy", mean_R.values)
    np.save(Path(results_dir) / "std_R.npy",  std_R.values)
    np.save(Path(results_dir) / "mean_Q.npy", mean_Q.values)
    np.save(Path(results_dir) / "std_Q.npy",  std_Q.values)

    return (
        X_train_R.values, y_train,
        X_val_R.values,   y_val,
        X_test_R.values,  y_test,
        X_train_Q.values, X_val_Q.values, X_test_Q.values,
    )


if __name__ == "__main__":
    prepare_data()
